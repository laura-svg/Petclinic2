package com.example.petclinic2.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/user")
public class UserViewControllerHTML {
    private static final Logger logger = LoggerFactory.getLogger(UserViewControllerHTML.class);

    @GetMapping("/profile")
    public String getUserProfile() {
        logger.info("User HTML profile accessed");
        return "user";
    }
}
