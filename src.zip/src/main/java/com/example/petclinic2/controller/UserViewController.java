package com.example.petclinic2.controller;

import com.example.petclinic2.model.Pet;
import com.example.petclinic2.model.Veterinarian;
import com.example.petclinic2.model.Visit;
import com.example.petclinic2.service.PetService;
import com.example.petclinic2.service.VeterinarianService;
import com.example.petclinic2.service.VisitService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/user")
public class UserViewController {
    private final VeterinarianService veterinarianService;
    private final PetService petService;
    private final VisitService visitService;

    public UserViewController(VeterinarianService veterinarianService, PetService petService, VisitService visitService) {
        this.veterinarianService = veterinarianService;
        this.petService = petService;
        this.visitService = visitService;
    }

    @GetMapping("/vets")
    public List<Veterinarian> getAllVets() {
        return veterinarianService.findAll();
    }

    @GetMapping("/pets")
    public List<Pet> getAllPets() {
        return petService.findAll();
    }

    @GetMapping("/visits")
    public List<Visit> getAllVisits() {
        return visitService.findAll();
    }
    private static final Logger logger = LoggerFactory.getLogger(UserViewController.class);

    @GetMapping("/profile")
    public String getUserProfile() {
        logger.info("User REST profile accessed");
        return "User profile via REST";
    }
}
