package com.example.petclinic2.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
    private JwtAuthFilter jwtAuthFilter;
    private UserDetailsService userDetailsService;

    @Autowired
    public SecurityConfig(UserDetailsService userDetailsService, JwtAuthFilter jwtAuthFilter) {
        this.userDetailsService = userDetailsService;
        this.jwtAuthFilter = jwtAuthFilter;
    }
        @Bean
  public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
      http
              // Вимкнення CSRF для API-запитів
              .csrf(csrf -> csrf.ignoringRequestMatchers("/api/**"))
              .authorizeHttpRequests(auth-> auth
                      // Публічні ресурси
                      .requestMatchers("/login", "/register", "/api/public/**", "/css/**", "/js/**").permitAll()
                      .requestMatchers("/auth/**").permitAll()
                      // ДОБАВЛЯЄМО ДОСТУП ДО КОНТРОЛЕРІВ ВЕТКЛІНІКИ:
                      .requestMatchers(HttpMethod.GET, "/pets/**", "/visits/**", "/vets/**").hasAnyRole("USER", "ADMIN")
                      .requestMatchers(HttpMethod.POST, "/pets/**", "/visits/**", "/vets/**").hasRole("ADMIN")
                      .requestMatchers(HttpMethod.PUT, "/pets/**", "/visits/**", "/vets/**").hasRole("ADMIN")
                      .requestMatchers(HttpMethod.DELETE, "/pets/**", "/visits/**", "/vets/**").hasRole("ADMIN")

                      // API-запити
                      .requestMatchers("/api/user/**").hasRole("USER")
                      .requestMatchers("/api/admin/**").hasRole("ADMIN")
                      // HTML-інтерфейси
                      .requestMatchers("/user/**").hasRole("USER")
                      .requestMatchers("/admin/**").hasRole("ADMIN")
                      // все інше – автентифікація
                      .anyRequest().authenticated()
              )
              // Форма логіну
              .formLogin(form -> form
                      .loginPage("/login")
                      .defaultSuccessUrl("/default", true)
                      .permitAll()
              )
              //  Basic auth (для REST-тестування)
              .httpBasic(Customizer.withDefaults())
              .logout(logout -> logout
               .logoutUrl("/logout")
              .logoutSuccessUrl("/login?logout")
              .permitAll()
              )
              //  Обробка відмов доступу
              .exceptionHandling(ex -> ex
                      .accessDeniedHandler((request, response, accessDeniedException) ->
                              response.sendRedirect("/access-denied"))
              )
              // Сесії тільки при потребі (для HTML)
              .sessionManagement(sess -> sess
                      .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED))
              .authenticationProvider(daoAuthenticationProvider());
            http.addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);
            return http.build();
  }

    @Bean
    public DaoAuthenticationProvider daoAuthenticationProvider()  {

        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(new BCryptPasswordEncoder());
        return provider;
    }



    @Bean
  public AuthenticationManager authenticationManager(HttpSecurity http, PasswordEncoder passwordEncoder, UserDetailsService userDetailsService) throws Exception {
      return http.getSharedObject(AuthenticationManagerBuilder.class)
              .userDetailsService(userDetailsService)
              .passwordEncoder(passwordEncoder)
              .and().build();
  }

  @Bean
    public PasswordEncoder passwordEncoder() {
      return new BCryptPasswordEncoder();
  }

}
