package com.example.petclinic2.service;

import com.example.petclinic2.model.Visit;
import com.example.petclinic2.repository.VisitRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class VisitService {

    private final VisitRepository visitRepository;
    
    public Visit save(Visit visit) {
        return visitRepository.save(visit);
    }

    public List<Visit> getVisitsByPetId(Long petId) {
        return visitRepository.findByPet_Id(petId);
    }

    public List<Visit> findAll() {
        return visitRepository.findAll();
    }
}
