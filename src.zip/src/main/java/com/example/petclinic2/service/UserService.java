package com.example.petclinic2.service;

import com.example.petclinic2.model.Role;
import com.example.petclinic2.model.User;
import com.example.petclinic2.repository.RoleRepository;
import com.example.petclinic2.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Set;
@Service
@Setter
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    public boolean usernameExists(String username) {
        return userRepository.findByLogin(username).isPresent();
    }

    public void registerUser(String username, String password) {
        if (usernameExists(username)) {
            throw new IllegalArgumentException("Username already exists");
        }

        Role userRole = roleRepository.findByRole("ROLE_USER")
                .orElseThrow(() -> new RuntimeException("Role USER not found"));

        User user = new User();
        user.setLogin(username);
        user.setPassword(passwordEncoder.encode(password));
        user.setCreatedAt(LocalDateTime.now());
        user.setRoles(Set.of(userRole));

        userRepository.save(user);
    }
}
