package com.example.petclinic2.repository;

import com.example.petclinic2.model.Pet;
import com.example.petclinic2.model.Veterinarian;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VeterenarianRepository extends JpaRepository <Veterinarian, Long> {
}
