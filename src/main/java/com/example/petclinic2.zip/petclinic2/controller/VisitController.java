package com.example.petclinic2.controller;

import com.example.petclinic2.model.Visit;
import com.example.petclinic2.repository.VisitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/visits")
public class VisitController {

    private VisitRepository visitRepository;
@Autowired
    public VisitController(VisitRepository visitRepository) {
        this.visitRepository = visitRepository;
    }

    @PostMapping
    public Visit addVisit(@RequestBody Visit visit) {
    return visitRepository.save(visit);
    }

    @GetMapping("/by-pet/{petId}")
    public List<Visit> getVisitsByPet(@PathVariable long petId) {
    return visitRepository.findByPetId(petId);
    }

}
