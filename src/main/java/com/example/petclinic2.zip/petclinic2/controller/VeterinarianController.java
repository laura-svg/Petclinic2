package com.example.petclinic2.controller;

import com.example.petclinic2.model.Veterinarian;
import com.example.petclinic2.repository.VeterenarianRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/vets")
public class VeterinarianController {

private VeterenarianRepository veterenarianRepository;
@Autowired
    public VeterinarianController(VeterenarianRepository veterenarianRepository) {
        this.veterenarianRepository = veterenarianRepository;
    }

    @GetMapping
    public List<Veterinarian> getAllVeterinarians() {
    return veterenarianRepository.findAll();
    }

    @GetMapping("/{id}")
    public Veterinarian getVeterinarianById(@PathVariable long id) {
    return veterenarianRepository.findById(id).orElse(null);
    }
}
