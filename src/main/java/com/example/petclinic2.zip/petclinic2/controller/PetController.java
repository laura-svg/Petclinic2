package com.example.petclinic2.controller;

import com.example.petclinic2.model.Pet;
import com.example.petclinic2.service.PetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pets")
public class PetController {
    private PetService petService;
    @Autowired
    public PetController(PetService petService) {
        this.petService = petService;
    }

    @GetMapping
    public List<Pet> getAllPets() {
        return petService.findAll();
    }

    @GetMapping("/{id}")
    public Pet getPetById(@PathVariable long id) {
        return petService.findById(id);
    }

    @PostMapping
    public Pet addPet(@RequestBody Pet pet) {
        return petService.save(pet);
    }

}
