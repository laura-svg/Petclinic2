package com.example.petclinic2.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Pet {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    private String name;
    private String species;
    private String ownerName;
    private LocalDate birthDate;

    @OneToMany(mappedBy = "pet")
    private List<Visit> visits;

}
