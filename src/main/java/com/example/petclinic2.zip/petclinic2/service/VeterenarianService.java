package com.example.petclinic2.service;

import com.example.petclinic2.model.Veterinarian;
import com.example.petclinic2.repository.VeterenarianRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VeterenarianService {

    private VeterenarianRepository veterenarianRepository;

    public VeterenarianService(VeterenarianRepository veterenarianRepository) {
        this.veterenarianRepository = veterenarianRepository;
    }

    public List<Veterinarian> findAll() {
        return veterenarianRepository.findAll();
    }

    public Veterinarian findById(Long id) {
        return veterenarianRepository.findById(id).orElse(null);
    }

    public Veterinarian save(Veterinarian veterinarian) {
        return veterenarianRepository.save(veterinarian);
    }
}
