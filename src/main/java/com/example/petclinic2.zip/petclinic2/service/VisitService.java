package com.example.petclinic2.service;

import com.example.petclinic2.model.Visit;
import com.example.petclinic2.repository.VisitRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VisitService {

    private VisitRepository visitRepository;
    public VisitService(VisitRepository visitRepository) {
        this.visitRepository = visitRepository;
    }

    public Visit save(Visit visit) {
        return visitRepository.save(visit);
    }

    public List<Visit> getVisitsByPetId(Long petId) {
        return visitRepository.findByPetId(petId);
    }

    public List<Visit> findAll() {
        return visitRepository.findAll();
    }
}
