package com.example.petclinic2.service;

import com.example.petclinic2.model.Pet;
import com.example.petclinic2.repository.PetRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PetService {

    private PetRepository petRepository;
    public PetService(PetRepository petRepository) {
        this.petRepository = petRepository;
    }
    public List<Pet> findAll() {
        return petRepository.findAll();
    }
    public Pet findById(Long id) {
        return petRepository.findById(id).orElse(null);
    }
    public Pet save(Pet pet) {
        return petRepository.save(pet);
    }
}
